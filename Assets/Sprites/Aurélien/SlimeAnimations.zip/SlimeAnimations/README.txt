[ENG]
Hello! Thank you for downloading this asset pack. If you need anything, or if there is something wrong with your purchase please contact me through any of the following means:

Portfolio: https://www.reffpixels.com/
Email: reffpixels@gmail.com

Twitter: https://twitter.com/reffpixels
Itch.io: https://reffpixels.itch.io/
Reddit: https://www.reddit.com/user/_Reff/
Discord: reffpixels

I'm also reffpixels in (most) social media, but the previous contact methods are preferable.

This is a very small free asset pack. You'll find a bunch of animations for a Slime I made long ago, this was just a test to begin making asset packs for itch.io

ANIMATIONS INCLUDED (12):
� Red Slime Jump Animation
� Red Slime Idle Animation
� Red Slime Attack Animation
� Red Slime Death Animation

� Blue Slime Jump Animation
� Blue Slime Idle Animation
� Blue Slime Attack Animation
� Red Slime Death Animation

� Green Slime Jump Animation
� Green Slime Idle Animation
� Green Slime Attack Animation
� Green Slime Death Animation

All animations are saved in gif and png!

NOTE: Ignore the "itchio" folder. These are edits of the assets used for the presentation on Itch.io
You may use the assets inside of it, but they are not properly crafted for games.